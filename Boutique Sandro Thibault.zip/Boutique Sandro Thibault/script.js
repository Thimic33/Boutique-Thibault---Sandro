
const produits = [
    {id: 1, nom: "Dragon Blanc", prix: 50},
    {id: 2, nom: "Serpent Gris", prix: 10},
    {id: 3, nom: "Le Gobelin", prix: 10},
    {id: 4, nom: "Dragon Infernal", prix: 100},
    {id: 5, nom: "Phoenix Glacé", prix: 75},
    {id: 6, nom: "Demon des ombres", prix: 85},
    {id: 7, nom: "Archère des bois", prix: 50},
    {id: 8, nom: "Ange Divin", prix: 250}
];

const points = 300;

let panier = JSON.parse(localStorage.getItem("panier")) || [];

function sauvegarderPanier() {
    localStorage.setItem("panier", JSON.stringify(panier));
}

// Nombre total d'articles
function afficherNombrePanier() {
    const compteur = document.getElementById("nombre-panier");

    if (!compteur) return;

    let nombre = panier.reduce(
        (somme, article) => somme + article.quantite,
        0
    );

    compteur.textContent = nombre;
}

// Calcul du total
function calculerTotal() {
    return panier.reduce(
        (somme, article) =>
            somme + article.prix * article.quantite,
        0
    );
}

// Ajouter au panier
function ajouterAuPanier(id) {
    const produit = produits.find(p => p.id === id);

    if (!produit) return;

    if (calculerTotal() + produit.prix > points) {
        alert("Tu n'as pas assez de points !");
        return;
    }

    const article = panier.find(p => p.id === id);

    if (article) {
        article.quantite++;
    } else {
        panier.push({...produit, quantite: 1});
    }

    sauvegarderPanier();
    afficherPanier();
}

// Modifier quantité
function modifierQuantite(id, changement) {
    const article = panier.find(p => p.id === id);

    if (!article) return;

    if (changement > 0 &&
        calculerTotal() + article.prix > points) {
        alert("Tu n'as pas assez de points !");
        return;
    }

    article.quantite += changement;

    if (article.quantite <= 0) {
        supprimerDuPanier(id);
        return;
    }

    sauvegarderPanier();
    afficherPanier();
}

// Supprimer un article
function supprimerDuPanier(id) {
    panier = panier.filter(p => p.id !== id);

    sauvegarderPanier();
    afficherPanier();
}

// Afficher le panier
function afficherPanier() {
    afficherNombrePanier();

    const contenu = document.getElementById("panier");
    const totalElement = document.getElementById("total");
    const pointsElement = document.getElementById("points-display");

    if (pointsElement) {
        pointsElement.textContent = points;
    }

    // Si on est sur la page boutique,
    // il n'y a pas de contenu de panier à afficher.
    if (!contenu || !totalElement) return;

    contenu.innerHTML = "";

    if (panier.length === 0) {
        contenu.innerHTML = `
            <p class="vide">Ton panier est vide. 🛒</p>
        `;
    }

    panier.forEach(article => {
        const sousTotal = article.prix * article.quantite;

        contenu.innerHTML += `
            <div class="article-panier">

                <h3>${article.nom}</h3>

                <p>${article.prix} points / unité</p>

                <button onclick="modifierQuantite(${article.id}, -1)">
                    -
                </button>

                ${article.quantite}

                <button onclick="modifierQuantite(${article.id}, 1)">
                    +
                </button>

                <button onclick="supprimerDuPanier(${article.id})">
                    Supprimer
                </button>

                <p>Sous-total : ${sousTotal} points</p>

            </div>
        `;
    });

    totalElement.textContent = calculerTotal();
}

// Initialisation
afficherPanier();
